import Student from "../model/student.js"

const studentController = {
    getStudents: (req, res, next) => {
        if (Object.keys(req.query).length === 0) {
            res.status(200).json(Student.getAll())
        }
        //next();
    }
};

export default studentController;