import exp from "constants"
import studentController from "../controller/studentController.js";
import express from "express"

const router = express.Router();

router.get('/', studentController.getStudents);


export default router;